﻿using System.Linq;

using System.Web.Mvc;

using $safeprojectname$.Models;

namespace MovieApp.Controllers
{

    public class HomeController : Controller
    {

        private $safeprojectname$.Models.MoviesDBEntities _db = new $safeprojectname$.Models.MoviesDBEntities();

        public ActionResult Index()
        {

            return View(_db.$safeprojectname$.Models.Movies.ToList());

        }

    }

}