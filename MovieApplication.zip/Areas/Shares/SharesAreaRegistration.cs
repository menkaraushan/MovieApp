﻿using System.Web.Mvc;

namespace $safeprojectname$.Areas.Shares
{
    public class SharesAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Shares";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Shares_default",
                "Shares/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
